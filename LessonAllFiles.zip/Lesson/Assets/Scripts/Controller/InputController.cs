﻿using UnityEngine;

namespace Geekbrains
{
	public sealed class InputController : BaseController, IOnUpdate
	{
		private KeyCode _activeFlashLight = KeyCode.F;              //клавиша вкл фн
		public void OnUpdate()
		{
			if (!IsActive) return;                                  //если выкл ВыХ
			if (Input.GetKeyDown(_activeFlashLight))                //если нажата нужная клавища
			{
				Main.Instance.FlashLightController.Switch();        // вызвать метод мереключения через синглтон
			}
		}
	}
}