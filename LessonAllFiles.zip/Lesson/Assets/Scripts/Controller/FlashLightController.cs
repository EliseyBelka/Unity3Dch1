﻿using UnityEngine;

namespace Geekbrains
{
	public sealed class FlashLightController : BaseController, IOnUpdate, IInitialization
	{
		private FlashLightModel _flashLightModel;                   //ссылка на модель нашего фонарика - отображение ФН
		private FlashLightUi _flashLightUi;                         //ссылка на вьюшку ФН - пока

		public void Init()                                          //при инициализации посик объектов
		{
			_flashLightModel = Object.FindObjectOfType<FlashLightModel>();
			_flashLightUi = Object.FindObjectOfType<FlashLightUi>();
            
		}

		public override void On()                                   //метод ВКл ФН
		{
			if(IsActive) return;                                    //если ФН уже вкл ВЫХ
			if (_flashLightModel == null) return;                   //объект фонарь не найден - ВЫХ
			if (_flashLightUi == null) return;                      //вьюшка не найдена ВЫХ
			if (_flashLightModel.BatteryChargeCurrent <= 0) return; //если закончился заряд выход
			base.On();                                              //если все уловия выше не выполнились то вкл фонарь
			_flashLightModel.Switch(true);                          //активация фонаря
			_flashLightUi.SetActive(true);                          //активация вьюшки заряда
		}

		public override void Off()                                  //метод ВыК ФН
        {
			if (!IsActive) return;                                  //если уже ВыКл выйти
			base.Off();                                             //выкл фонарь
			_flashLightModel.Switch(false);                         //деактивир ФН
            
            //_flashLightUi.SetActive(false);                       //деактив вьюшку
        }

		public void OnUpdate()
		{
            if (_flashLightModel.BatteryChargeCurrent < 0) Off();   //еслия полный разряд выкл ФН

            if (!IsActive)                                          //если не включен
                _flashLightModel.BatteryCharge();                   //зарядка
            else                                                    //иначе                
            {
                _flashLightModel.Rotation();                        //перенос
                _flashLightModel.EditBatteryCharge();               //разрядка
            }

            _flashLightUi.Text = _flashLightModel.BatteryChargeCurrent*10;
            _flashLightUi.Bar = _flashLightModel.BatteryChargeCurrent/10;

        }
	}
}