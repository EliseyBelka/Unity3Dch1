﻿using UnityEngine;
using UnityEngine.UI;

namespace Geekbrains
{
    public sealed class FlashLightUi : MonoBehaviour
    {
	    private Text _text;
        public static Image _bar;          //!!! РАЗОБРАТЬСЯ почему не могу использовать PRIVAT для Image, 
                                           //если оставить -> не работает GetComponent<Image> - null. Как вариант privat component[]
       
	    private void Awake()
	    {
            _bar = GetComponent<Image>(); //ссылка на Картинку куда выводится заряд батареи
            _text = GetComponent<Text>(); //ссылка на текст куда выводится заряд батареи
        }

         public void SetActive(bool value) //включение и выкл отображения ФН
	    {
            _bar.gameObject.SetActive(value);
            _text.gameObject.SetActive(value);
        }

        public float Text //передач значения в параметр по маске
        {
            set { _text.text = $"{value:0}"; }
        }

        public float Bar //передач значения в параметр по маске
        {
            set { _bar.fillAmount = value; }
        }

       
    }
}
