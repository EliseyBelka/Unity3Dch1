﻿namespace Geekbrains
{
	public interface IInitialization
	{
		void Init();
	}
}