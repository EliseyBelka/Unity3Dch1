﻿using UnityEngine;

namespace Geekbrains
{
	public sealed class FlashLightModel : BaseObjectScene
	{
		private Light _light;                                               //ссылка на источник света
		private Transform _goFollow;                                        //объект следования
		private Vector3 _vecOffset;                                         //вектор смещения
		public float BatteryChargeCurrent { get; private set; }             //заряд батареи
		[SerializeField] private float _speed = 10;                         //скорость перемещения
		[SerializeField] private float _batteryChargeMax;                   //максимальный заряд батареи

		protected override void Awake()                                     //переопределенный Awake 
		{
			base.Awake();                                                   //базовый функционал класса
			_light = GetComponent<Light>();
			_goFollow = Camera.main.transform;
			_vecOffset = transform.position - _goFollow.position;
			BatteryChargeCurrent = _batteryChargeMax;
		}

		public void Switch(bool value)                                      //вкл/выкл фонарика
		{
			_light.enabled = value;                                         //присвоить переданное значение в метод (состояние фонарика)
			if (!value) return;                                             //если не вклчен выйти
			transform.position = _goFollow.position + _vecOffset;           //включен переместится в "голову"
			transform.rotation = _goFollow.rotation;
		}

		public void Rotation()                                              //метод перемещения вфонаря в голову
		{
			transform.position = _goFollow.position + _vecOffset;
			transform.rotation = Quaternion.Lerp(transform.rotation,
				_goFollow.rotation, _speed * Time.deltaTime);
		}

		public void EditBatteryCharge()
		{
			if (BatteryChargeCurrent > 0)
		
				BatteryChargeCurrent -= Time.deltaTime;

		}

        public void BatteryCharge()
        {
            if (BatteryChargeCurrent<_batteryChargeMax)

                BatteryChargeCurrent += Time.deltaTime;
  
           
        }
    }
}