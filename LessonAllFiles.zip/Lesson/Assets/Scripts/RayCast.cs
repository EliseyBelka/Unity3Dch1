﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RayCast : MonoBehaviour {
    private float Dist = 50f;
    public static Text _text;

    private void Start()
    {
        _text = GameObject.Find("Sans").GetComponent<Text>();
    }

    void Update()
    {
        Ray ray = new Ray(transform.position, transform.forward);
        RaycastHit Hit;
        if (Physics.Raycast(ray, out Hit, Dist))
        {
            _text.text = "you're looking at:" + Hit.collider.name;
        }
        else _text.text="";
    }
}
