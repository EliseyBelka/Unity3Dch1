﻿using System.Collections.Generic;
using UnityEngine;

namespace Geekbrains
{
	//Инит и апдейт
    // service Locator - паттрн для юнити (связывает между собой код) 
	public sealed class Main : MonoBehaviour
	{
		public FlashLightController FlashLightController { get; private set; } //создание контроллера ФН
		public InputController InputController { get; private set; }    //вводной контроллер
		public PlayerController PlayerController { get; private set; }  //контролька игрока

		private readonly List<IOnUpdate> _updates = new List<IOnUpdate>(); //список обновляемых объетов
		private Transform Player;   //ссылка на персонажа

		public static Main Instance { get; private set; } //типо синглтон для связи оъектов внутри игры, позволяет получит
        //доступ из любой части программы через main. ...
		
		private void Awake()
		{
			Instance = this; //ссылка на саого себя ддля инициализации

			Player = GameObject.FindGameObjectWithTag("Player").transform; //поиск игрока
			
			PlayerController = new PlayerController(new UnitMotor(Player));//инициализация контроллера игрока чз мотор
			_updates.Add(PlayerController); //добавление в список обновляемых контроллеров

			FlashLightController = new FlashLightController();
			_updates.Add(FlashLightController);

			InputController = new InputController();
			_updates.Add(InputController);
		}

		private void Start()
		{
			FlashLightController.Init(); //иниц контроллера ФН
			InputController.On(); //возможно управлять игрой
		}

		private void Update() //запуск апдейтов по порядку
		{
			for (var i = 0; i < _updates.Count; i++)
			{
				_updates[i].OnUpdate();
			}
		}
	}
}
